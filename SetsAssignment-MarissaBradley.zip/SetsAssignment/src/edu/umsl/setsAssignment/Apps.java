package edu.umsl.setsAssignment;
import java.io.*;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Apps {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in)); //allows user to input the patient records

		Set<Patient> p = new HashSet<Patient>(); //use set interface
		
		int i = 1;
		while(i<=10) { //only 10 patient records
			//Prompts user for patient records:
			System.out.println("Enter Patient ID: ");
			int patientID = Integer.parseInt(read.readLine());
			System.out.println("Enter Patient First Name: ");
			String patientFirstName = read.readLine();
			System.out.println("Enter Patient Last Name: ");
			String patientLastName = read.readLine();
			System.out.println("Enter Patient illness: ");
			String patientIllness = read.readLine();
			System.out.println("Enter Patient Notes: ");
			String patientNotes = read.readLine();

			p.add(new Patient(patientID, patientFirstName, patientLastName, patientIllness, patientNotes));
			i++;	
		}
		//sorts by last name using comparator:
		class PatientLastName implements Comparator<Patient>{

			public int compare(Patient o1, Patient o2) {

				return o1.lastName.compareTo(o2.lastName);
			}

		}

		TreeSet<Patient> patientTree = new TreeSet<Patient>(new PatientLastName());
		patientTree.addAll(p); //adds all elements in specified collection to this set (p)
		for(Patient thisPatient: patientTree) {
			System.out.println("Patient ID:" + thisPatient.ID 
					+ " Patient First Name: " + thisPatient.firstName 
					+ " Patient Last Name: " + thisPatient.lastName 
					+ " Patient Illness: " + thisPatient.illness 
					+ " Patient Notes: " + thisPatient.notes);
		}
	}
}
