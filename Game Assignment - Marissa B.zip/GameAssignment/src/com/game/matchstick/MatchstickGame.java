package com.game.matchstick;
import java.util.Scanner;
public class MatchstickGame {

	public static void main(String[] args) {
	
		Scanner keyboard = new Scanner(System.in);
		String player; //computer's opponent
		int matchstick = 0; //matchsticks used for the game
		int total = 0; //total number of matchsticks
		
		while(total<21) {
			System.out.println("Choose 1,2,3, or 4 matchsticks \n");
			matchstick = keyboard.nextInt(); //read in number from player
			
			while(matchstick > 4) {
				System.out.println("Cannot have more than 4 matchsticks. Please choose a different number:");
				matchstick = keyboard.nextInt(); //reads in next number entered by player
			}
		
			total += matchstick; //add the amount the player picked to the total amount of matchsticks
		
			if(total >= 21) {
				System.out.println("You have picked the last matchstick. You Lose. Computer Wins.");
				return; //do not continue on with code. game ends
			}
		
			System.out.println("Now the computer will take its turn \n");
			//The computer picks the matchstick so that the total is 5:
			if(matchstick == 1) {
				total += 4;
				System.out.println("The computer chose 4 matchsticks \n");
			}
			
			if(matchstick == 2) {
				total += 3;
				System.out.println("The computer chose 3 matchsticks \n");
			}
			
			if(matchstick == 3) {
				total += 2;
				System.out.println("The computer chose 2 matchsticks \n");
			}
			
			if(matchstick == 4) {
				total += 1;
				System.out.println("The computer chose 1 matchstick \n");
			}
		}
	}
}

