package com.threeDArray.numbers;
public class MultiDimensionalArray {

	public static void main(String[] args) {
		int array[][][] = new int[2][3][4]; //3D array with dimensions of 2,3,& 4
		int i, j, k, num = 1; //initialize variables
		//iterates through 3D array
		for(i=0; i<2; i++) {
			for(j=0; j<3; j++) {
				for(k=0; k<4; k++) {
					array[i][j][k] = num; //numbers that will fit in the array
					num++;
				}
			}
		}
		//iterates through 3d array again to retrieve all numbers and print them to the console
		for(i=0; i<2; i++) {
			for(j=0; j<3; j++) {
				for(k=0; k<4; k++) {
					System.out.println(array[i][j][k]);
				}
			}
		}
	}
}